import { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // Importando o useNavigate
import { auth, googleProvider } from './firebaseConfig'; // Adicionando o googleProvider
import { createUserWithEmailAndPassword, signInWithPopup } from 'firebase/auth'; // Importando o método signInWithPopup
import { doc, setDoc } from 'firebase/firestore';
import { db } from './firebaseConfig';
import './Cadastro.css';

function Cadastro() {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [confirmarSenha, setConfirmarSenha] = useState('');
  const [nome, setNome] = useState('');
  const [erro, setErro] = useState('');

  const navigate = useNavigate(); // Inicializando o useNavigate

  const handleCadastro = async (e) => {
    e.preventDefault();

    if (senha !== confirmarSenha) {
      setErro('As senhas não coincidem.');
      return;
    }

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, senha);
      const user = userCredential.user;

      await setDoc(doc(db, 'usuarios', user.uid), {
        nome: nome,
        email: email,
        senha: senha, // Senha não deveria ser armazenada por segurança
      });

      alert('Cadastro realizado com sucesso!');
    } catch (err) {
      setErro('Erro ao cadastrar usuário. Tente novamente.');
      console.error(err);
    }
  };

  const handleGoogleCadastro = async (e) => {
    e.preventDefault();
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const user = result.user;

      await setDoc(doc(db, 'usuarios', user.uid), {
        nome: user.displayName, // Nome do usuário do Google
        email: user.email,
        senha: '', // Não há senha quando se utiliza o login Google
      });

      alert('Cadastro realizado com sucesso com o Google!');
    } catch (err) {
      setErro('Erro ao cadastrar com o Google. Tente novamente.');
      console.error(err);
    }
  };

  const irParaLogin = () => {
    navigate('/Login'); // Navega para a tela de login
  };

  return (
    <div className="cadastro">
      <h2>Cadastro</h2>
      <form onSubmit={handleCadastro}>
        <div>
          <label>Nome:</label>
          <input
            type="text"
            value={nome}
            onChange={(e) => setNome(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Email:</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Senha:</label>
          <input
            type="password"
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Confirmar Senha:</label>
          <input
            type="password"
            value={confirmarSenha}
            onChange={(e) => setConfirmarSenha(e.target.value)}
            required
          />
        </div>
        {erro && <p className="erro">{erro}</p>}
        <button type="submit">Criar Cadastro</button>
      </form>

      <button className="google-button" onClick={handleGoogleCadastro}>
        Criar Cadastro com o Google
      </button>

      <button className="login-button" onClick={irParaLogin}>
        Já possuo cadastro
      </button>
    </div>
  );
}

export default Cadastro;
