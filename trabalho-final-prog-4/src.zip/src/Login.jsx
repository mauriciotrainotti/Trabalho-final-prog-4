import { useState } from 'react';
import { auth, googleProvider } from './firebaseConfig'; // Importando as configurações do Firebase
import { signInWithEmailAndPassword, signInWithPopup } from 'firebase/auth'; // Métodos de autenticação
import { doc, getDoc } from 'firebase/firestore'; // Para buscar dados do Firestore
import { db } from './firebaseConfig'; // Importa a instância do Firestore
import './Login.css';

function Login() {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState('');

  // Função para login com email e senha
  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, senha);
      const user = userCredential.user;

      // Verificar se o usuário está no Firestore
      const docRef = doc(db, 'usuarios', user.uid);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        alert('Login realizado com sucesso!');
        // Redirecionar ou realizar outras ações após login
      } else {
        setErro('Usuário não encontrado no banco de dados.');
        // Desconectar o usuário do Firebase
        await auth.signOut();
      }
    } catch (err) {
      setErro('Erro ao realizar login. Tente novamente.');
      console.error(err);
    }
  };

  // Função para login com o Google
  const handleGoogleLogin = async (e) => {
    e.preventDefault();
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const user = result.user;

      // Verificar se o usuário está no Firestore
      const docRef = doc(db, 'usuarios', user.uid);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        alert('Login realizado com sucesso com o Google!');
        // Redirecionar ou realizar outras ações após login
      } else {
        setErro('Usuário não encontrado no banco de dados.');
        // Desconectar o usuário do Firebase
        await auth.signOut();
      }
    } catch (err) {
      setErro('Erro ao realizar login com o Google. Tente novamente.');
      console.error(err);
    }
  };

  return (
    <div className="login">
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <div>
          <label>Email:</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Senha:</label>
          <input
            type="password"
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
            required
          />
        </div>
        {erro && <p className="erro">{erro}</p>}
        <button type="submit">Fazer Login</button>
      </form>

      <button className="google-button" onClick={handleGoogleLogin}>
        Login com Google
      </button>
    </div>
  );
}

export default Login;
