import { useState, useEffect } from 'react';
import { db, auth, googleProvider } from './firebaseConfig'; // Importa os serviços de Auth e Firestore
import { doc, getDoc, setDoc, updateDoc, collection, addDoc } from 'firebase/firestore';
import { createUserWithEmailAndPassword, signInWithPopup } from 'firebase/auth'; // Importa funções de autenticação
import './App.css';
import Cadastro from './Cadastro'; // A tela de cadastro estará aqui

function App() {
  // Controle de navegação
  const [currentScreen, setCurrentScreen] = useState('cadastro'); // Alterado para 'cadastro' como valor inicial

  // States para controlar a visibilidade dos modais
  const [modalAdicionarSaldoAberto, setModalAdicionarSaldoAberto] = useState(false);
  const [modalAdicionarDespesaAberto, setModalAdicionarDespesaAberto] = useState(false);

  // States para o saldo e o valor do novo saldo
  const [saldo, setSaldo] = useState(500); // Valor inicial
  const [novoSaldo, setNovoSaldo] = useState('');

  // State para armazenar as despesas
  const [despesas, setDespesas] = useState([]);

  // State para armazenar o usuário autenticado
  const [user, setUser] = useState(null);

  // Função para alternar entre as telas
  const navegarPara = (tela) => setCurrentScreen(tela);

  // Função de login com Google
  const handleLoginGoogle = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const user = result.user;
  
      // Verifica se o usuário já existe no Firestore
      const userDocRef = doc(db, 'usuarios', user.uid);
      const docSnap = await getDoc(userDocRef);
  
      if (!docSnap.exists()) {
        await setDoc(userDocRef, {
          uid: user.uid,
          nome: user.displayName || '',
          email: user.email,
          fotoUrl: user.photoURL || '',
          criadoEm: new Date().toISOString(),
        });
  
        console.log('Usuário Google salvo no Firestore:', user.uid);
      }
  
      setUser(user); // Atualiza o estado do usuário logado
    } catch (error) {
      console.error('Erro ao autenticar com Google:', error);
    }
  };

  // Função de cadastro de usuário
  const handleCadastro = async (email, senha, nome) => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, senha);
      const user = userCredential.user;
  
      // Salva as informações do usuário no Firestore
      const userDocRef = doc(db, 'usuarios', user.uid);
      await setDoc(userDocRef, {
        uid: user.uid,
        nome: nome || '', // Nome passado no formulário
        email: user.email,
        criadoEm: new Date().toISOString(),
      });
  
      console.log('Usuário cadastrado no Firestore:', user.uid);
      setUser(user); // Atualiza o estado do usuário logado
      navegarPara('home'); // Volta para a tela principal
    } catch (error) {
      console.error('Erro ao cadastrar usuário no Firestore:', error);
    }
  };

  return (
    <div className="App">
      {currentScreen === 'home' && (
        <>
          <header className="header">
            <button className="menu-button">☰ Menu</button>
            <div className="balance-section">
              <span className="balance">Saldo Atual: R$ {saldo.toFixed(2)}</span>
              <button
                className="add-balance-button"
                onClick={() => setModalAdicionarSaldoAberto(true)}
              >
                + Adicionar Saldo
              </button>
            </div>
          </header>

          <div className="content-area">
            {user ? (
              <div className="user-info">
                <span className="ola-user">Olá, {user.displayName}!</span>
              </div>
            ) : (
              <button onClick={() => navegarPara('cadastro')}>Ir para Cadastro</button>
            )}
          </div>
        </>
      )}

      {currentScreen === 'cadastro' && (
        <Cadastro
          handleCadastro={handleCadastro}
          handleLoginGoogle={handleLoginGoogle}
          voltarParaHome={() => navegarPara('home')}
        />
      )}
    </div>
  );
}

export default App;
